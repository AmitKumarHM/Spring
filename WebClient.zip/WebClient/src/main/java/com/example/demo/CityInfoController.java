package com.example.demo;

import java.util.HashMap;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cache.CacheManager;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.google.common.cache.Cache;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixProperty;

@RestController
public class CityInfoController {

	@Value("${weatherservice.base_url}")
	private String weatherServiceBaseUrl;
	
	private HashMap<String, String> cache=new HashMap<>();
	
	private RestTemplate restTemplate=new RestTemplate();
	

	@GetMapping("/weather/{city}")
	@HystrixCommand(fallbackMethod="getWeatherInformationFromCache",commandProperties= {@HystrixProperty(name="execution.isolation.thread.timeoutInMilliseconds",value="400")})
	public String getCurrentTemperature(@PathVariable("city") String city) {
		System.out.println("**********Callling getCurrentTemperature");
		String url=weatherServiceBaseUrl+"/"+city;
		ResponseEntity<String> responseEntity=restTemplate.getForEntity(url, String.class);
		cache.put(city,responseEntity.getBody());
		return responseEntity.getBody();
	}

	public String getWeatherInformationFromCache(String city) {
		System.out.println("**********Callling getWeatherInformationFromCache");
		String message=cache.get(city);
		if(message==null)
		 return message="From Cache: WeatherService may be down ";
		return "From Cache: "+message;
	}
	public RestTemplate getRestTemplate() {
		return restTemplate;
	}

	public void setRestTemplate(RestTemplate restTemplate) {
		this.restTemplate = restTemplate;
	}
	
}
