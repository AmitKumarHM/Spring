package demo;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jms.annotation.EnableJms;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

@Component
@EnableScheduling
public class Sender {
	@Autowired
	private JmsTemplate jmstemplate;

	@PostConstruct
	public void init() {
		jmstemplate.setPubSubDomain(true);
	}

	// private String destname="queue/MyQueue";
	private String destname = "topic/MyTopic";
	private int cnt = 0;

	@Scheduled(initialDelay = 0, fixedRate = 20000)
	public void sendUser() {
		User u1 = new User();
		u1.setId(cnt++);
		u1.setFirst_name("Vai" + cnt);
		u1.setLast_name("T" + cnt);
		u1.setAvatar("Avatar of " + u1.getFirst_name());

		jmstemplate.convertAndSend(destname, u1);
		System.out.println("sending User " + u1);
	}

	@Scheduled(initialDelay = 10000, fixedRate = 20000)
	public void sendEmp() {
		Emp e1 = new Emp();
		e1.setEmpno(cnt++);
		e1.setEname("Simran" + cnt);
		e1.setSalary(cnt * 1000);
		jmstemplate.convertAndSend(destname, e1);
		System.out.println("sending Emp " + e1);
	}
}
