package com.synech.feign;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.feign.EnableFeignClients;
import org.springframework.context.annotation.Bean;

@SpringBootApplication
@EnableFeignClients
public class FeignApplication {

	@Autowired
	private EmployeeClient employeeClient;
	
	public static void main(String[] args) {
		SpringApplication.run(FeignApplication.class, args);
	}
	
	@Bean
	public String getEmployees(){
		System.out.println("Get Employees");
		employeeClient.list().forEach(System.out::println);
		return "done";
	}
}
