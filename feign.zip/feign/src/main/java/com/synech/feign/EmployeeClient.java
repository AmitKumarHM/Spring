package com.synech.feign;

import java.util.List;

import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@FeignClient(name="firstclient", url="http://localhost:9093")
public interface EmployeeClient {

	@RequestMapping(method=RequestMethod.GET,value="/")
	public List<Employee> list();
	
	@RequestMapping(method=RequestMethod.POST)
	public Employee save(Employee employee);
}
