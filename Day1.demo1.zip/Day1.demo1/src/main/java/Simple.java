public class Simple {

	public static void main(String[] args) {
		for(int j = 0 ; j<5;j++)
		{
			Runnable r = ()->{
					for(int i = 0; i< 50;i++){
							System.out.println("Run method of support1 " + i );
					}};
			(new Thread(r)).start();
		}
	}
}
