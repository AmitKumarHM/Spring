import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

class CallableSupport1 implements Runnable{
	@Override
	public void run() {
		// TODO Auto-generated method stub
		for(int i = 0; i< 150;i++){
			if (( i % 15)==0)
			{
				System.out.println("Run method of support1 " + i   + ",  Current Thread = " + Thread.currentThread().getName());
				System.out.println("percentage of work completed = " +  (i / 1.5) + " % " );
			}	
			
	}
	}
}
public class CallableDemo1 {

	public static void main(String[] args) {
		Runnable r = new CallableSupport1();
		Callable<String> callable = Executors.callable(r, "completed in callable ..");
		ScheduledExecutorService ses = Executors.newScheduledThreadPool(1);
		
		Future future = ses.submit(r);
		try {
			System.out.println("Future = "  + future.get(1,TimeUnit.MILLISECONDS));
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ExecutionException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (TimeoutException e) {
			System.out.println("TimeOUt ");
		}
		ses.shutdown();
	}

}
