import java.io.FileOutputStream;
import java.util.Date;
import java.util.concurrent.Callable;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.ScheduledExecutorService;

class CallableSupprt2 implements Callable<String>
{
	private String status ="Starting .."; 
	public String getStatus (){
		return status;
	}

	@Override
	public String call() throws Exception {
		try{
			FileOutputStream fos = new FileOutputStream("tmp.txt");
			for(int i = 0; i< 150;i++){
				
				String str= "\rHello "+ new Date();
			if ((i % 15 )==0)
				status =  (i /1.5)  + " % Done " ;
				fos.write(str.getBytes());
				Thread.sleep(100);
			}
			fos.close();
		}catch (Exception e) {
			System.out.println("In Exception  " + e);
			throw e;
		}
		
		return "Completed....";
	}

	}

public class CallableDemo2 {

	public static void main(String[] args) throws Exception{
		CallableSupprt2 cs2 = new CallableSupprt2();
		ScheduledExecutorService ses = Executors.newScheduledThreadPool(1);
		Future<String> future = ses.submit(cs2);
		System.out.println("after future...");
		for( int i = 0; i < 10;i++){
				System.out.println(cs2.getStatus());
				Thread.sleep(500);
		}
		System.out.println("Future value =  "+ future.get() );
		ses.shutdown();
	}

}
