import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
class EDSupport implements Runnable{
	@Override
	public void run() {
		// TODO Auto-generated method stub
		for(int i = 0; i< 15;i++){
			System.out.println("Run method of support1 " + i   + ",  Current Thread = " + Thread.currentThread().getName());
	}
	}
}
public class ExecutorDemo {

	public static void main(String[] args) {
		Runnable r =  new EDSupport();
		//ExecutorService service = Executors.newFixedThreadPool(2);
		ExecutorService service = Executors.newCachedThreadPool();
		service.execute(r);
		service.execute(r);
		service.execute(r);
		service.execute(r);
		service.shutdown();
	}
}
  