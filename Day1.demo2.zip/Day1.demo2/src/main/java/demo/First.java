package demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.core.task.TaskExecutor;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.stereotype.Component;

@Component
@Scope(value="prototype")
public class First {
	public First() {
	System.out.println( " in first constructor...");
	}
	@Autowired
	private TaskExecutor txe;
	
	public void m1(){
		System.out.println("m1 invoke d...");
		Runnable r = ()->{
			for(int i = 0; i< 15;i++){
					System.out.println("Run method of support1 " + i  +  ", " + Thread.currentThread().getName());
			}};
	
	
		txe.execute(r);
	}
}
