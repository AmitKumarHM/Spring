package demo;

import java.util.Date;

import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

@Component
@EnableScheduling
public class Second {

@Scheduled(initialDelay=5000, fixedRate=1000)
	public void m1()
	{
		System.out.println(" m1 invoked ..." + new Date()  +"...." + Thread.currentThread().getName());
		for(int i = 0;i<5;i++)
		{
			System.out.print(".");
			try {
				Thread.sleep((long)(Math.random()*1000));
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		System.out.println(" m1 finished ..." + new Date()  +"...." + Thread.currentThread().getName());
	}

@Scheduled(initialDelay=5000,fixedDelay=1000)
public void m2()
{
	System.out.println(" m2 invoked ..." + new Date()  +"...." + Thread.currentThread().getName());
	for(int i = 0;i<5;i++)
	{
		System.out.print(".");
		try {
			Thread.sleep((long)(Math.random()*1000));
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	System.out.println(" m2 finished ..." + new Date()  +"...." + Thread.currentThread().getName());
}

@Scheduled(cron="0 * * * * ?")
public void m3(){
	System.out.println(" m3 invoked ..." + new Date()  +"...." + Thread.currentThread().getName());
}
}
