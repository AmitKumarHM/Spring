package demo;

import java.util.concurrent.Future;

import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.AsyncResult;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.stereotype.Component;

@Component
@EnableAsync
public class Third {
	@Async
	public void m1(){
		System.out.println("third  in method m1 ");
		for(int i = 0;i<15;i++){
			System.out.print("    Third.. m1..." + i + ", " + Thread.currentThread().getName()) ;
		}
		System.out.println("\n\n");
	}
	@Async
	public Future<String> m2(String name) 
	{
		System.out.println(" in method m2 " + ", " + Thread.currentThread().getName());
		for(int i = 0;i<15;i++){
			System.out.print("    Third.. m2..." + i );
		}
		System.out.println("\n\n");
		if ((name.length() %2) ==0 )
			return  new AsyncResult<String>( "Invalid Name ");
		
		return  new AsyncResult<String>( "completed m2...");
	}
}
