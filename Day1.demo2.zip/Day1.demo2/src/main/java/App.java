import java.util.Date;
import java.util.Scanner;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Scope;
import org.springframework.core.task.TaskExecutor;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

import demo.First;
import demo.Third;

@SpringBootApplication(scanBasePackages = "demo")
public class App {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scanner= new Scanner(System.in);
		System.out.println("Press a number to continue...");
		scanner.nextInt();
		
		ConfigurableApplicationContext ctx = SpringApplication.run(App.class, args);
		
		System.out.println("Started . ." + new Date());
		Third th = ctx.getBean(Third.class);
		th.m1();
		System.out.println("after m1 .. ");
		System.out.println("before m2 ");
		Future<String> futurestr = null;

		futurestr = th.m2("Abcd");

		System.out.println("after m2 ");
		try {
			System.out.println("data is returned .." + futurestr.get(2, TimeUnit.SECONDS));
		} catch (InterruptedException e) {
			System.out.println("InterruptedException");
			e.printStackTrace();
		} catch (ExecutionException e) {
			System.out.println("ExecutionException");
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (TimeoutException e) {
			System.out.println("TimeoutException");
			e.printStackTrace();
		} catch (Exception e) {
			System.out.println("Exception ...");
			e.printStackTrace();
		}

	
		for(int i = 1;i<15;i++)
		{
			First first = ctx.getBean(First.class);
			first.m1();	
		}
		
		//	ctx.close();
	}

	@Bean
	@Scope(value="prototype")
	public TaskExecutor taskexe() {
		ThreadPoolTaskExecutor txe = new ThreadPoolTaskExecutor();
		txe.setCorePoolSize(1);
		txe.setMaxPoolSize(4);
		txe.setQueueCapacity(2);
		return txe;
	}

}
