package com.synechron.streamexp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ImportResource;

@SpringBootApplication
@ImportResource(value="integrationdemo.xml")
public class StreamexpApplication {

	public static void main(String[] args) {
		SpringApplication.run(StreamexpApplication.class, args);
		//System.out.println("Process a number to complete...");
		//new Scanner(System.in).nextInt();
		while(true) {
			
		}
	}
}
