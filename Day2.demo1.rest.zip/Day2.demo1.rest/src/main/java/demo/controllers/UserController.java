package demo.controllers;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collector;
import java.util.stream.Collectors;

import javax.xml.ws.Response;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import demo.models.User;
import demo.repo.UserRepository;

@RestController
@RequestMapping(value="/")
public class UserController {
	@Autowired
	private UserRepository repo;
	
	@GetMapping(produces={MediaType.APPLICATION_JSON_VALUE,MediaType.APPLICATION_XML_VALUE})
	public List<User> list(){
		return repo.list();
	}
	
	@GetMapping(value="/q" , produces={MediaType.APPLICATION_JSON_VALUE,MediaType.APPLICATION_XML_VALUE})
	public List<User> list(@RequestParam(required=true,name="name") String name){
		return repo.list().stream().filter((u)->u.getFirst_name().equalsIgnoreCase(name) || u.getLast_name().equalsIgnoreCase(name)).collect(Collectors.toList());
	}
	
	@GetMapping(value="/{uid}", produces={MediaType.APPLICATION_JSON_VALUE,MediaType.APPLICATION_XML_VALUE})
	public ResponseEntity<User> singleuser(@PathVariable(name="uid")int uid){
		Optional<User> u  =  repo.list().stream().filter((usr)-> usr.getId()==uid).findFirst();
		if (u.isPresent())
			return ResponseEntity.ok(u.get());
		else
			return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
	}
	
	@DeleteMapping(value="/{uid}")
	public ResponseEntity<?> delete(@PathVariable(name="uid")int uid)
	{
		if (repo.list().removeIf((usr)->usr.getId()==uid))
			return ResponseEntity.status(HttpStatus.NO_CONTENT).build();
		else
			return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
	}
	@PutMapping(value="/", consumes=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> update(@RequestBody User user)
	{
		System.out.println(" in update " + user);
		Optional<User> u  =  repo.list().stream().filter((usr)-> usr.getId()==user.getId()).findFirst();
		System.out.println(u.isPresent());
		if (u.isPresent())
			{		
			repo.update(user);
			return ResponseEntity.status(HttpStatus.OK).build();
			}
		else
			return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
			}
	
@PostMapping(value="/", consumes=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> save(@RequestBody User user)
	{
		repo.create(user);
		return ResponseEntity.status(HttpStatus.OK).build();
	}
}
