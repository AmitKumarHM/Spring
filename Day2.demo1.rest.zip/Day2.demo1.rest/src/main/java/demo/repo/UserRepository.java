package demo.repo;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import demo.models.User;
@Component
public class UserRepository {
	private List<User> list = new ArrayList<>();
	
	public void create(User user){
		System.out.println("UserRepo - Create " + user);
		list.add(user);
	}
	
	public void delete(int id)
	{
		System.out.println("delete " + id);
		list.removeIf((e)-> e.getId()==id);
	}
	public void update(User newuser)
	{
		System.out.println( "Update   " + newuser);
		list.forEach((usr)->{
			if (usr.getId()==newuser.getId())
			{
				usr.setFirst_name(newuser.getFirst_name());
				usr.setLast_name(newuser.getLast_name());
				usr.setAvatar(newuser.getAvatar());
			}
		});
	}
	public  List<User> list(){
		System.out.println("list " + list.size());
		return list;
	}
}
