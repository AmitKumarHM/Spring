import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Scanner;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Scope;
import org.springframework.core.task.TaskExecutor;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

import demo.models.User;
import demo.repo.UserRepository;

@SpringBootApplication(scanBasePackages = "demo")
public class RestApp {

	public static void main(String[] args) {
		ConfigurableApplicationContext ctx = SpringApplication.run(RestApp.class, args);
		UserRepository userrepo = ctx.getBean(UserRepository.class);
		List<String> firstnames = Arrays.asList("Kavita","Kayra","Vaishali");
		List<String> lastnames = Arrays.asList("Tapaswi","Savant","Bura");
		for (int i = 1; i<= 3; i++){
			User user = new User(i,firstnames.get(i % firstnames.size()), lastnames.get(i % lastnames.size()),"avatar"+i);
			userrepo.create(user);
		}
		userrepo.list().forEach(System.out::println);
		userrepo.delete(2);
		User user1 = new User (1,"Shriram","Kanak","sk");
		userrepo.update(user1);
		userrepo.list().forEach(System.out::println);
		
	}
}
