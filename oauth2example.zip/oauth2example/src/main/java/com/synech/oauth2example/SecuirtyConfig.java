package com.synech.oauth2example;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;

@Configuration
@EnableGlobalMethodSecurity(securedEnabled=true, prePostEnabled=true)
public class SecuirtyConfig {

	
	 @Autowired
	 private DataSource dataSource;
	
	  @Autowired
      public void configureGlobal(AuthenticationManagerBuilder auth) {
              /*try {
				auth.inMemoryAuthentication().withUser("user1").password("pass").roles("admin")
				                  .and().withUser("user2").password("pass").roles("stduser");
			} catch (Exception e) {
				System.out.println("**************Exception");
				e.printStackTrace();
			}*/
		  System.out.println("****************************"+dataSource);
		  try {
			auth.jdbcAuthentication().dataSource(dataSource).usersByUsernameQuery("select username, password, enabled from users where username=?").authoritiesByUsernameQuery("select username,role from roles where username=?");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		  
		  
      }
	  
	  @Bean
	  public DataSource getDataSource(){
		 return new DriverManagerDataSource("jdbc:hsqldb:hsql://localhost/", "sa", ""); 
	  }
}
