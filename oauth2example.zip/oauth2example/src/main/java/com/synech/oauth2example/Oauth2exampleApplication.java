package com.synech.oauth2example;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.context.SecurityContextImpl;

//@EnableWebSecurity
//@SpringBootApplication
@Configuration
@ComponentScan(basePackages="com.synech.oauth2example")
public class Oauth2exampleApplication {

	private static AnnotationConfigApplicationContext cac;
	
	public static void main(String[] args) {
		//ConfigurableApplicationContext cac=SpringApplication.run(Oauth2exampleApplication.class, args);
		
		cac = new AnnotationConfigApplicationContext(Oauth2exampleApplication.class);
		MyBusinessLogic b=cac.getBean(com.synech.oauth2example.MyBusinessLogic.class);
		SecurityContext sm=new SecurityContextImpl();
		Authentication auth=new UsernamePasswordAuthenticationToken("user2", "pass");
		sm.setAuthentication(auth);
		SecurityContextHolder.setContext(sm);
		try{
			b.m1();
		}catch(Exception ex){
			System.out.println(ex);
		}
		
		try{
			b.m2();	
		}catch (Exception e) {
			System.out.println(e);
		}
	}
	
	
}
