package com.synech.securityexample;

import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.stereotype.Component;


@Component
public class LoginConfigurer extends WebSecurityConfigurerAdapter {
@Override
protected void configure(HttpSecurity http) throws Exception {
	//super.configure(http);
	
	http.antMatcher("/admin/**").authorizeRequests().anyRequest().authenticated().and().logout().logoutUrl("/my/logout").permitAll().logoutSuccessUrl("/").and().httpBasic();
}

@Override
	protected void configure(AuthenticationManagerBuilder auth) throws Exception {
		//super.configure(auth);
		  try {
		auth.inMemoryAuthentication().withUser("user1").password("pass").roles("admin")
		                  .and().withUser("user2").password("pass").roles("stduser");
	} catch (Exception e) {
		System.out.println("**************Exception");
		e.printStackTrace();
	}
	}
	
}
