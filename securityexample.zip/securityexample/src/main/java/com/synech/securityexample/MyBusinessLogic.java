package com.synech.securityexample;

import org.springframework.stereotype.Component;

@Component
public class MyBusinessLogic {
	//@Secured(value="ROLE_admin")
	public void m1(){
		System.out.println("m1");
	}

	//@Secured(value="ROLE_stduser")
	public void m2(){
		System.out.println("m2");
	}


}
