import java.net.URI;
import java.net.URL;
import java.util.Arrays;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

public class GetConsumerForReqRes {

	public static void main(String[] args) throws Exception {
	String url = "https://reqres.in/api/users?page=1";
	RestTemplate template = new RestTemplate();
	HttpHeaders headers = new HttpHeaders();
	headers.set("User-Agent", "Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36");
	HttpEntity entity = new HttpEntity("",headers);
	
		
	String resp = template.exchange(new URI(url),HttpMethod.GET,entity, String.class).getBody();
	System.out.println(" Default get for object...");
	System.out.println(resp);
	
	}

}
