import java.io.IOException;
import java.net.URI;
import java.net.URL;
import java.util.Arrays;
import java.util.Collections;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpRequest;
import org.springframework.http.MediaType;
import org.springframework.http.client.ClientHttpRequestExecution;
import org.springframework.http.client.ClientHttpRequestInterceptor;
import org.springframework.http.client.ClientHttpResponse;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;
class MyInterceptor implements ClientHttpRequestInterceptor
{

	@Override
	public ClientHttpResponse intercept(HttpRequest request, byte[] body, ClientHttpRequestExecution execution)
			throws IOException {
		System.out.println("in intercept...");
		request.getHeaders().add("Accept", MediaType.APPLICATION_XML_VALUE);
		return execution.execute(request, body);
	}
	}
public class GetConsumer2 {

	public static void main(String[] args) throws Exception {
	String url = "http://localhost:8080";
	RestTemplate template = new RestTemplate();
	template.setInterceptors(Collections.singletonList(new MyInterceptor()));
		
	String resp = template.getForObject(url,String.class);
	System.out.println(" Default get for object...");
	System.out.println(resp);
	 resp = template.getForObject(url + "/3",String.class);
	System.out.println(" Default get/3 for object...");
	System.out.println(resp);
	
	UriComponentsBuilder builder = UriComponentsBuilder.fromUri(new URI(url + "/q")).queryParam("name", "kanak" );
	System.out.println(builder.buildAndExpand(url).toUri());
	
	resp = template.exchange(builder.buildAndExpand(url).toUri(), HttpMethod.GET,null,String.class).getBody();
	System.out.println(" QueryParam  get name=kanak for");
	System.out.println(resp);
	
	 builder = UriComponentsBuilder.fromUri(new URI(url + "/q")).queryParam("name", "kanak" );
	System.out.println(builder.buildAndExpand(url).toUri());
	HttpHeaders headers = new HttpHeaders();
	headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
	HttpEntity entity = new HttpEntity("",headers);
	
	resp = template.exchange(builder.buildAndExpand(url).toUri(), HttpMethod.GET,entity,String.class).getBody();
	System.out.println(" QueryParam  get name=kanak for");
	System.out.println(resp);
	
	
	
	}

}
