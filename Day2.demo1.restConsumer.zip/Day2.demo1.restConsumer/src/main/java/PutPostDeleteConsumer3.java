import java.net.URI;
import java.util.Arrays;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

public class PutPostDeleteConsumer3 {
public static void main(String[] args) throws Exception{
	String url = "http://localhost:8085";
	RestTemplate template = new RestTemplate();
	template.delete(url + "/1");
	
/*	HttpHeaders headers = new HttpHeaders();
	headers.setContentType(MediaType.APPLICATION_JSON);
	MultiValueMap<String,String> map = new LinkedMultiValueMap<>();
	map.add("id", "1");
	map.add("first_name", "Vaishali" );
	map.add("last_name", "Tapaswi");
	map.add("avatar","aaa");
	HttpEntity entity = new HttpEntity(map);
*/
	String s= "{\"id\":1,\"first_name\":\"Shriram\",\"last_name\":\"Kanak\",\"avatar\":\"sk\"}";
	//ResponseEntity<String> str = template..postForEntity(url, s, String.class);
	UriComponentsBuilder builder = UriComponentsBuilder.fromUri(new URI(url));
	HttpHeaders headers = new HttpHeaders();
	headers.setContentType(MediaType.APPLICATION_JSON);
	HttpEntity entity = new HttpEntity(s,headers);
	
	ResponseEntity<String>resp = template.exchange
			(builder.buildAndExpand(url).toUri(), HttpMethod.POST,entity,String.class);
	System.out.println(resp.getStatusCode());

	 s= "{\"id\":1,\"first_name\":\"AAAAAAAA\",\"last_name\":\"BBBBB\",\"avatar\":\"sk\"}";
	//ResponseEntity<String> str = template..postForEntity(url, s, String.class);
	UriComponentsBuilder builder1 = UriComponentsBuilder.fromUri(new URI(url));
	HttpHeaders headers1 = new HttpHeaders();
	headers1.setContentType(MediaType.APPLICATION_JSON);
	HttpEntity entity1 = new HttpEntity(s,headers);
	
	 resp = template.exchange
			(builder1.buildAndExpand(url).toUri(), HttpMethod.PUT,entity1,String.class);
	System.out.println(resp.getStatusCode());
	
}
}
