import java.net.URI;
import java.net.URL;
import java.util.Arrays;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

public class GetConsumer1 {

	public static void main(String[] args) throws Exception {
	String url = "http://localhost:8080";
	RestTemplate template = new RestTemplate();
	
		
	String resp = template.getForObject(url,String.class);
	System.out.println(" Default get for object...");
	System.out.println(resp);
	 resp = template.getForObject(url + "/3",String.class);
	System.out.println(" Default get/3 for object...");
	
	System.out.println(resp);
	
	UriComponentsBuilder builder = UriComponentsBuilder.fromUri(new URI(url + "/q")).queryParam("name", "kanak" );
	System.out.println(builder.buildAndExpand(url).toUri());
	HttpHeaders headers = new HttpHeaders();
	headers.setAccept(Arrays.asList(MediaType.APPLICATION_XML));
	HttpEntity entity = new HttpEntity("",headers);
	
	resp = template.exchange(builder.buildAndExpand(url).toUri(), HttpMethod.GET,entity,String.class).getBody();
	System.out.println(" QueryParam  get name=kanak for");
	System.out.println(resp);
	
	}

}
