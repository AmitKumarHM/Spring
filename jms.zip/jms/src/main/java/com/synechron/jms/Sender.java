package com.synechron.jms;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

@Component
@EnableScheduling
public class Sender {

	@Autowired
	private JmsTemplate jmsTemplate;
	
	@Autowired
	private JmsTemplate jmsTemplate1;
	
	@PostConstruct
	public void init() {
		jmsTemplate.setPubSubDomain(true);
	}
	private static int count;
	
	//@Scheduled(initialDelay=6000,fixedRate=10000)
	public void sendMessage() {
		User user = new User();
		//jmst.convertAndSend("queue/MyQueue", "FirstMsgfromSpring" + new Date());
		jmsTemplate1.convertAndSend("queue/MyQueue", user);
		System.out.println("convert and send done ..");
	}
	
	@Scheduled(initialDelay=1000,fixedRate=1000)
	public void sendTopicMessage() {
		User user = new User();
		//jmst.convertAndSend("queue/MyQueue", "FirstMsgfromSpring" + new Date());
		jmsTemplate.convertAndSend("topic/MyTopic", user);
		System.out.println("User convert and send done as Topic .."+ ++count);
	}
	
}
