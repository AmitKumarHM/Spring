package com.synechron.jms;

import org.springframework.jms.annotation.JmsListener;
import org.springframework.stereotype.Component;

@Component
public class MyMessageRecevier {

//@JmsListener(destination="queue/MyQueue",containerFactory="myFactoryQueue")
 public void recevieMessage(com.synechron.jms.User s) {
	 System.out.println("Received "+s);
 }
	
@JmsListener(destination="topic/MyTopic",containerFactory="myFactory")
public void recevieTopic(com.synechron.jms.User s) {
	 System.out.println("Received "+s);
}
	
}
