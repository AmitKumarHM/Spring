package com.example.demo;

import javax.jms.JMSException;
import javax.jms.Queue;

import org.springframework.stereotype.Component;

@Component
public class QueueComponent {

	private Queue queue;

	public Queue getQueue() {
		return queue;
	}

	public void setQueue(Queue queue) {
		this.queue = queue;
	}

	public QueueComponent() {
		queue=new Queue() {	
			@Override
			public String getQueueName() throws JMSException {
				return "StockQueue";
			}
		};
		
	}
	
	
	
}
