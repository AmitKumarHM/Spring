package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class StockController {

	@Autowired
	JmsTemplate jmsTemplate;
	@Autowired
	QueueComponent queueComponent;
	
	@GetMapping("/stock/{name}")
	public String greet(@PathVariable("name") String name) {
	
		jmsTemplate.convertAndSend("StockQueue",name);
		return "Send Successfully";
	}
}
