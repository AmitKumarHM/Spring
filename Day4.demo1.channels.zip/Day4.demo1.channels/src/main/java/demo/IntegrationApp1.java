package demo;
import java.util.Scanner;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.ImportResource;

@SpringBootApplication
@ImportResource(value="integrationdemo1.xml")
public class IntegrationApp1 {

	public static void main(String[] args) {
		ConfigurableApplicationContext ctx = SpringApplication.run(IntegrationApp1.class, args);
	/*	System.out.println("Press a number to complete ...");
		new Scanner(System.in).nextInt();*/
		while(true){}
	}

}
