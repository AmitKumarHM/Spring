package com.synech.oauth2example2;

import java.util.Date;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ResponseBody;



@Controller
public class EmployeeController {

	@GetMapping(value="/help")
	public String m1(){
		System.out.println("Date and Time App2 "+new Date());
		return "/help1.html";
	}
	
	@GetMapping(value="/admin/m1")
	public @ResponseBody String m2(){
		System.out.println("Date and Time App2 "+new Date());
		return "<h1>Hello App2</h1>";
	}
	
	@GetMapping(value="/admin/m2")
	public @ResponseBody String m3(){
		System.out.println("Date and Time App2 "+new Date());
		return "<h1>Hello App2</h1>";
	}
	
	@GetMapping(value="/my/login")
	public @ResponseBody String mm(){
		System.out.println("Date and Time App2 "+new Date());
		return "redirect: /#/";
	}
}
