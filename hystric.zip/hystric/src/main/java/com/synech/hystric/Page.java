package com.synech.hystric;

import java.util.ArrayList;

public class Page {
 private Integer page;
 private Integer per_page;
 private Integer total_page;
 private Integer total;
 private ArrayList<Employee> data;
public Integer getPage() {
	return page;
}
public void setPage(Integer page) {
	this.page = page;
}
public Integer getPer_page() {
	return per_page;
}
public void setPer_page(Integer per_page) {
	this.per_page = per_page;
}
public Integer getTotal_page() {
	return total_page;
}
public void setTotal_page(Integer total_page) {
	this.total_page = total_page;
}
public Integer getTotal() {
	return total;
}
public void setTotal(Integer total) {
	this.total = total;
}
public ArrayList<Employee> getData() {
	return data;
}
public void setData(ArrayList<Employee> data) {
	this.data = data;
}
 

}
