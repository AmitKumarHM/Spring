package com.synech.hystric;

import java.util.ArrayList;
import java.util.List;

import org.springframework.cloud.client.circuitbreaker.EnableCircuitBreaker;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.client.RestTemplate;

import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;



@Controller
@EnableCircuitBreaker
@RequestMapping("/")
public class EmployeeController {

	private Page page;
	public EmployeeController() {
		this.page = new Page();
		this.page.setPer_page(10);
		this.page.setTotal(100);
		this.page.setTotal_page(20);
		this.page.setPage(1);
		
		ArrayList< Employee> list=new ArrayList<>();
		list.add(new Employee(1,1,"A","Z","HR",10000));
		list.add(new Employee(2,2,"B","Y","QA",10000));
		list.add(new Employee(3,3,"C","X","DEV",10000));
		list.add(new Employee(4,4,"D","W","QA",10000));
		list.add(new Employee(5,5,"E","V","HR",10000));
		list.add(new Employee(6,6,"F","U","DEV",10000));
		this.page.setData(list);
	}

	@GetMapping
	public String getIndex() {
		return "/index.html";
	}
	
	@GetMapping(value="/list")
	@ResponseBody
	@HystrixCommand(commandKey = "inventory-by-productcode",fallbackMethod = "staticdata")
	public String getList() {
		RestTemplate restTemplate=new RestTemplate();
		ResponseEntity<String> str=restTemplate.getForEntity("http://localhost:8085/employees", String.class);
		return str.getBody();
	}
	
	
	public String staticdata() {
		return "/list.html";
	}
	
	@GetMapping(value="/employees")
	public @ResponseBody List<Employee> getEmployees() {
		return page.getData();
	}
	
	@GetMapping("/users")
	public @ResponseBody Page getAllEmployees() {
		return page;
	}
	
	@GetMapping("/users/{id}")
	public @ResponseBody Employee getEmployee(@PathVariable("id") Integer id) {
		return page.getData().get(id);
	}
	
		
	@PostMapping(value="/users",consumes=MediaType.APPLICATION_JSON_VALUE)
	public @ResponseBody Employee saveEmployee(@RequestBody Employee employee) {
		employee.setEmpno(page.getData().size()+1); 
		page.getData().add(employee);
		return employee;
	}
}
