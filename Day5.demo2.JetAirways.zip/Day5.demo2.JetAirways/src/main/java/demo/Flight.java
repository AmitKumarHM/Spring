package demo;

public class Flight {
	private String from;
	private String to;
	private int flno;
	private int date;
	
public Flight(){}	
	public Flight(String from, String to, int flno, int date) {
		
		this.from = from;
		this.to = to;
		this.flno = flno;
		this.date = date;
	}


	public String getFrom() {
		return from;
	}
	public void setFrom(String from) {
		this.from = from;
	}
	public String getTo() {
		return to;
	}
	public void setTo(String to) {
		this.to = to;
	}
	public int getFlno() {
		return flno;
	}
	public void setFlno(int flno) {
		this.flno = flno;
	}
	public int getDate() {
		return date;
	}
	public void setDate(int date) {
		this.date = date;
	}
	@Override
	public String toString() {
		return "Flight [from=" + from + ", to=" + to + ", flno=" + flno + ", date=" + date + "]";
	}
	
}
