package demo;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.integration.support.MessageBuilder;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Component;

@Component(value="jet")
public class JetComponent {

	private Logger logger = LoggerFactory.getLogger(this.getClass().getName());
	public Message<?> getjetflt(Message<?> msg)
	{
		System.out.println("Get of JetComponent invoked ..");
		logger.info("Get of JetComponent Invoked ..." );
		List<Flight> list = new ArrayList<Flight>();
		list.add(new Flight("PNQ","DEL", 1, 10));
		list.add(new Flight("DEL","PNQ",2, 11));
		list.add(new Flight("HYD","DEL", 3, 12));
		list.add(new Flight("DEL","HYD", 4, 13));
		list.add(new Flight("HYD","PNQ", 5, 14));
		list.add(new Flight("PNQ","HYD", 6, 15));
		return MessageBuilder.withPayload(list)
				.copyHeadersIfAbsent(msg.getHeaders())
				.setHeader("http_statusCode",HttpStatus.OK)
				.build();
	}
}
