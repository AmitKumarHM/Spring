package demo;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ImportResource;

@SpringBootApplication
@ImportResource("classpath:jet-inbound-gateway.xml")
public class JetApplication {

	public static void main(String[] args) {
		SpringApplication.run(JetApplication.class, args);

	}

}
