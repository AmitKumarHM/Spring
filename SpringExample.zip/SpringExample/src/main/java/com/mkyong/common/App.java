package com.mkyong.common;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.mkyong.stock.bo.StockBo;
import com.mkyong.stock.model.Stock;

public class App {
    private static ApplicationContext appContext;

	public static void main( String[] args ){
    	appContext = new ClassPathXmlApplicationContext("spring/config/BeanLocations.xml");
    	System.out.println(appContext);
    	
    	
    	StockBo stockBo = (StockBo)appContext.getBean("stockBo");
    	System.out.println(stockBo);
    	
    	/** insert **/
    	//Stock stock = new Stock();
    	//stock.setStockCode("7668");
    	//stock.setStockName("HAIO");
    	//stockBo.save(stock);
    	
    	/** select **/
    	long time1=System.currentTimeMillis();
    	Stock stock2 = stockBo.findByStockCode("7668");
    	long time2=System.currentTimeMillis();
    	System.out.println(time2-time1);
    	
    	Stock stock3 = stockBo.findByStockCode("7668");
    	long time3=System.currentTimeMillis();
    	System.out.println(time3-time2);
    	
    	Stock stock4 = stockBo.findByStockCode("766");
    	long time4=System.currentTimeMillis();
    	System.out.println(time4-time3);
    	
    	Stock stock5 = stockBo.findByStockCode("7668");
    	long time5=System.currentTimeMillis();
    	System.out.println(time5-time4);
    	
    	
    	Stock stock6 = stockBo.findByStockCode("766");
    	long time6=System.currentTimeMillis();
    	System.out.println(time6-time5);
    	

    	Stock stock7 = stockBo.findByStockCode("66");
    	long time7=System.currentTimeMillis();
    	System.out.println(time7-time6);

    	Stock stock8 = stockBo.findByStockCode("766");
    	long time8=System.currentTimeMillis();
    	System.out.println(time8-time7);
    	
    	
    	/** update **/
    	//stock2.setStockName("HAIO-1");
    	//stockBo.update(stock2);
    	
    	/** delete **/
    	//stockBo.delete(stock2);
    	
    	System.out.println("Done");
    }
}
