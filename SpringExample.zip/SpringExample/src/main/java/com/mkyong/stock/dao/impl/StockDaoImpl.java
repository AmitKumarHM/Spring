package com.mkyong.stock.dao.impl;



import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.mkyong.stock.dao.StockDao;
import com.mkyong.stock.model.Stock;

@Repository
public class StockDaoImpl implements StockDao{

	@Autowired
	private SessionFactory sessionFactory;

	public SessionFactory getSessionFactory() {
		return sessionFactory;
	}

	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	public Stock findByStockCode(String stockCode){
		//List list = sessionFactory.openSession().load("from Stock where stockCode=?",stockCode);
		//return (Stock)list.get(0);
	    return null;
	}

	public void save(Stock stock1) {
		Session session=sessionFactory.openSession();
		Transaction transaction=session.beginTransaction();
		try {
		for ( int i = 1; i < 100000000; i++ ) {
			Stock stock = new Stock();
	    	stock.setStockCode("7668");
	    	stock.setStockName("HAIO"+i);
	         	if( i % 50 == 0 ) {
	               session.flush();
	               session.clear();
	              // throw new RuntimeException();
	            }
	    	session.save(stock);
			}
			transaction.commit();
		}
		catch (RuntimeException e) {
            if (transaction!=null)transaction.rollback();
            e.printStackTrace(); 
         } finally {
            session.close(); 
         }
		
	}

	public void update(Stock stock) {
		sessionFactory.openSession().update(stock);

	}

	public void delete(Stock stock) {
		sessionFactory.openSession().delete(stock);

	}

}
