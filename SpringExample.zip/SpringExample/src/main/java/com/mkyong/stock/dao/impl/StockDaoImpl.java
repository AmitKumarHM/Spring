package com.mkyong.stock.dao.impl;





import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.envers.AuditReader;
import org.hibernate.envers.AuditReaderFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.mkyong.stock.dao.StockDao;
import com.mkyong.stock.model.Stock;

@Repository
public class StockDaoImpl implements StockDao{

	@Autowired
	private SessionFactory sessionFactory;

	public SessionFactory getSessionFactory() {
		return sessionFactory;
	}

	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	public Stock findByStockCode(String stockCode){
		Session session=sessionFactory.openSession();
	    
		Query query=session.createQuery("FROM Stock where stockCode=:stockCode");
		query.setParameter("stockCode", stockCode);
		//query.setCacheable(true);
		query.setCacheRegion("Stock");
		@SuppressWarnings("unchecked")
		List<Stock> list=query.list();
		if(list!=null && list.size()>0) {
			AuditReader auditReader=AuditReaderFactory.get(session);
			List<Number> revisionNumbers = auditReader.getRevisions(Stock.class,list.get(0).getStockId());
		    for (Number rev : revisionNumbers) {
		    	System.out.println(rev);
		    }
		}
		session.close(); 
	    return list!=null && list.size()>0?list.get(0):null;
	}

	public void save(Stock stock1) {
		Session session=sessionFactory.openSession();
		Transaction transaction=session.beginTransaction();
		try {
		for ( int i = 1; i < 100; i++ ) {
			Stock stock = new Stock();
	    	stock.setStockCode("7668");
	    	stock.setStockName("HAIO"+i);
	         	if( i % 50 == 0 ) {
	               session.flush();
	               session.clear();
	              // throw new RuntimeException();
	            }
	    	session.save(stock);
			}
			transaction.commit();
		}
		catch (RuntimeException e) {
            if (transaction!=null)transaction.rollback();
            e.printStackTrace(); 
         } finally {
            session.close(); 
         }
		
	}

	public void update(Stock stock) {
		sessionFactory.openSession().update(stock);

	}

	public void delete(Stock stock) {
		sessionFactory.openSession().delete(stock);

	}

}
