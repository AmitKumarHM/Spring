package hello;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Map;

import javax.sql.DataSource;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.launch.support.RunIdIncrementer;
import org.springframework.batch.item.database.BeanPropertyItemSqlParameterSourceProvider;
import org.springframework.batch.item.database.JdbcBatchItemWriter;
import org.springframework.batch.item.database.JdbcCursorItemReader;
import org.springframework.batch.item.database.builder.JdbcBatchItemWriterBuilder;
import org.springframework.batch.item.database.builder.JdbcCursorItemReaderBuilder;
import org.springframework.batch.item.file.FlatFileItemWriter;
import org.springframework.batch.item.file.builder.FlatFileItemWriterBuilder;
import org.springframework.batch.item.file.transform.BeanWrapperFieldExtractor;
import org.springframework.batch.item.file.transform.DelimitedLineAggregator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.FileSystemResource;
import org.springframework.jdbc.core.RowMapper;

@Configuration
@EnableBatchProcessing
public class BatchConfiguration {

	@Autowired
	public JobBuilderFactory jobBuilderFactory;

	@Autowired
	public StepBuilderFactory stepBuilderFactory;

	@Autowired
	public DataSource ds;

	@Bean
	public JdbcCursorItemReader<Person> reader(DataSource dataSource) {
		return new JdbcCursorItemReaderBuilder<Person>().name("jdbcReader").dataSource(dataSource)
				.sql("select p.first_name,p.last_name from People p ").rowMapper(new RowMapper<Person>() {
					@Override
					public Person mapRow(ResultSet rs, int rownumber) throws SQLException {
						Person p = new Person();
						p.setFirstName(rs.getString(1));
						p.setLastName(rs.getString(2));
						return p;
					}
				}).build();
	}

	@Bean
	public FlatFileItemWriter<Person> writer() {
		return new FlatFileItemWriterBuilder<Person>()
                .name("fileName")
                .resource(new FileSystemResource("/demos/abc.txt"))
                .lineAggregator(new DelimitedLineAggregator<Person>()
                {
                    {
                        setDelimiter(",");
                        BeanWrapperFieldExtractor<Person> fieldExtractor = new BeanWrapperFieldExtractor<Person>();
                		fieldExtractor.setNames(new String[] { "firstName", "lastName" });
                		setFieldExtractor(fieldExtractor);
                    }
                })
                .build();
	/*	FlatFileItemWriter<Person> writer = new FlatFileItemWriter<Person>();
		writer.setResource(new FileSystemResource("/demos/abc.txt"));
		DelimitedLineAggregator<Person> delLineAgg = new DelimitedLineAggregator<Person>();
		delLineAgg.setDelimiter(",");
		BeanWrapperFieldExtractor<Person> fieldExtractor = new BeanWrapperFieldExtractor<Person>();
		fieldExtractor.setNames(new String[] { "firstName", "lastName" });
		delLineAgg.setFieldExtractor(fieldExtractor);
		writer.setLineAggregator(delLineAgg);
		return writer;*/
	}

	@Bean
	public PersonItemProcessor processor() {
		return new PersonItemProcessor();
	}

	// tag::jobstep[]
	@Bean
	public Job importUserJob(JobCompletionNotificationListener listener, Step step1) {
		return jobBuilderFactory.get("importUserJob").incrementer(new RunIdIncrementer()).listener(listener).flow(step1)
				.end().build();
	}

	@Bean
	public Step step1(FlatFileItemWriter<Person> writer) {
		return stepBuilderFactory.get("step1").<Person, Person>chunk(1).reader(reader(ds)).processor(processor())
				.writer(writer).build();
	}
	// end::jobstep[]
}