DROP TABLE people IF EXISTS;

CREATE TABLE people  (
    first_name VARCHAR(20)  PRIMARY KEY,
    last_name VARCHAR(20)
);

insert into people values ('aa1','aa1');
insert into people values ('aa2','aa2');
insert into people values ('aa3','aa3');
insert into people values ('aa4','aa4');
insert into people values ('aa5','aa5');
insert into people values ('aa6','aa6');