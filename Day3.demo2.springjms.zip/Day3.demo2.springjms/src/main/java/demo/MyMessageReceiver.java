package demo;
import org.springframework.jms.annotation.JmsListener;
import org.springframework.stereotype.Component;

@Component
public class MyMessageReceiver {

	@JmsListener(destination="queue/MyQueue", containerFactory="myFactory")
	public void receiveMessage(User s)
	{
		System.out.println("Received "+ s);
	}
}
