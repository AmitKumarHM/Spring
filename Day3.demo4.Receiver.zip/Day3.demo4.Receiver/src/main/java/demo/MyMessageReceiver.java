package demo;
import org.springframework.jms.annotation.JmsListener;
import org.springframework.stereotype.Component;

@Component
public class MyMessageReceiver {

//	@JmsListener(destination="queue/MyQueue", containerFactory="myFactory")
	@JmsListener(destination="topic/MyTopic", containerFactory="myFactory")
	public void receiveMessage(Object object)
	{
		System.out.println("Receive " + object);
	/*if (object instanceof Emp)	
		System.out.println("EmpInfo " + ((Emp)object).toString());
	if( object instanceof User)
		System.out.println("EmpInfo " +  ((User)object).toString());
	else
		System.out.println(" Unknown format " + object.getClass());
		*/
	}
}
