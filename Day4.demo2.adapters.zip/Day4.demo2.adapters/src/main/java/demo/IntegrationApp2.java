package demo;
import javax.jms.ConnectionFactory;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.jms.DefaultJmsListenerContainerFactoryConfigurer;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ImportResource;
import org.springframework.jms.annotation.EnableJms;
import org.springframework.jms.config.DefaultJmsListenerContainerFactory;
import org.springframework.jms.config.JmsListenerContainerFactory;

@SpringBootApplication
@ImportResource(value="integrationdemo2.xml")
public class IntegrationApp2 {

	public static void main(String[] args) {
		ConfigurableApplicationContext ctx = SpringApplication.run(IntegrationApp2.class, args);
	/*	System.out.println("Press a number to complete ...");
		new Scanner(System.in).nextInt();*/
		while(true){}
	}
/*	@Bean
	public JmsListenerContainerFactory<?> myFactory(ConnectionFactory connectionFactory,
			DefaultJmsListenerContainerFactoryConfigurer configurer) {
		DefaultJmsListenerContainerFactory factory = new DefaultJmsListenerContainerFactory();
		
		configurer.configure(factory, connectionFactory);
		factory.setPubSubDomain(true);
		return factory;
	}*/
}
