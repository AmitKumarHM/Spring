package com.synech.restservices;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.PropertySource;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@PropertySource(value= {"config.properties"})
public class EmployeeController {
	@Autowired
	private Prop prop;
	
	@Value(value="${jdbc.username}")
	private String userName;

	@RequestMapping(value="/emp")
	public Employee getEmployee() {
		System.out.println("Your Employee is executed successfully");
		return new Employee("AAAA", "SE","123901238");
	}
	
	
	@GetMapping(value="/prop")
	public String getPropertry() {
		System.out.println("Your Employee is executed successfully");
		
		int i=10;
		int j= 20;
		
		i= i ^ j;
		j= i ^ j;
		i= i ^ j;
		
		System.out.println(prop);
		return userName+" "+i+" "+j;
	}
}
