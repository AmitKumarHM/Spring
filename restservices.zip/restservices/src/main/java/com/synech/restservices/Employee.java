package com.synech.restservices;

public class Employee {

	private String namee;
	private String designation;
	private String salery;
	
	
	public Employee(String namee, String designation, String salery) {
		this.namee = namee;
		this.designation = designation;
		this.salery = salery;
	}
	
	public Employee() {
	}
	public String getNamee() {
		return namee;
	}
	public void setNamee(String namee) {
		this.namee = namee;
	}
	public String getDesignation() {
		return designation;
	}
	public void setDesignation(String designation) {
		this.designation = designation;
	}
	public String getSalery() {
		return salery;
	}
	public void setSalery(String salery) {
		this.salery = salery;
	}
	
	
}
