package com.synech.restservices;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;

@SpringBootApplication(scanBasePackages="com.synech.restservices")
public class RestservicesApplication {

	public static void main(String[] args) {
		ConfigurableApplicationContext caf=SpringApplication.run(RestservicesApplication.class, args);
		MessageService ms=caf.getBean(MessageService.class);
		ms.message();
	}
}
