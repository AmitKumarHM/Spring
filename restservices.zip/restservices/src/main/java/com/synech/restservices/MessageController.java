package com.synech.restservices;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class MessageController {
	@RequestMapping(value="/m1")
	public String getMessage() {
		System.out.println("Your Logic is executed successfully");
		return "m1.html";
	}
	
	@RequestMapping(value="/m2")
	public String getMessage2() {
		System.out.println("Your Logic is executed successfully");
		return "m2.jsp";
	}
}
