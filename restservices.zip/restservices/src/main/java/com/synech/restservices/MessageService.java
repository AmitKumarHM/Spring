package com.synech.restservices;

import org.springframework.stereotype.Component;

@Component
public class MessageService {

	void message() {
		System.out.println("Running the Logic");
	}
}
