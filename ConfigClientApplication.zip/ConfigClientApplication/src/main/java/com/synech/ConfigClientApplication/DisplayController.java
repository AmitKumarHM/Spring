package com.synech.ConfigClientApplication;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RefreshScope
@RequestMapping(value="/")
public class DisplayController {

	@Value(value="${message:mydefaulthello}")
	private String message;
	
	@GetMapping
	String getDsiplay(){
		return "<h1>"+message+"</h1>";
	}
}
