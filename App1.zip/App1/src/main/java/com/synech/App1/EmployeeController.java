package com.synech.App1;

import java.util.Date;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;



@RestController

public class EmployeeController {

	
	@GetMapping
	String getDsiplay(){
		System.out.println("Date and Time App1 "+new Date());
		return "<h1>Hello App1</h1>";
	}
	
	
}
