package com.synech.empjpademo;



import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.data.domain.Example;
import org.springframework.data.domain.ExampleMatcher;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;



@SpringBootApplication(scanBasePackages="com.synech.empjpademo")
@EnableJpaRepositories(basePackages="com.synech.empjpademo")
@EntityScan(basePackages="com.synech.empjpademo")
public class EmpjpademoApplication {

	public static void main(String[] args) {
		ConfigurableApplicationContext ctx=SpringApplication.run(EmpjpademoApplication.class, args);
		EmployeeDao deptDao=ctx.getBean(EmployeeDao.class);
		System.out.println(deptDao.setName("Amit", 150));
		Employee emp=deptDao.findOne(150);
		emp.setSalary(0);
		emp.setEmpno(null);
		/*List<String> names=(List) Arrays.asList("A","B","C","D","E");
		List<String> de=(List) Arrays.asList("HR","Training","Leraning","Finance","Sales");
		for(int i=0;i<200;i++)
		deptDao.save(new Employee(names.get(i%names.size()),de.get(i%de.size()),12000));*/
		System.out.println(emp);
		ExampleMatcher matcher=ExampleMatcher.matchingAny();
		Example<Employee> empexample=Example.of(emp,matcher);
		System.out.println(deptDao.findAll(empexample));
	}
	
	
	@Bean
	public String fetchAll(EmployeeDao deptDao){
	 Pageable page= (Pageable) new PageRequest(0, 10,new Sort(Sort.Direction.ASC, "department"));
	//	Pageable page= (Pageable) new PageRequest(0, 10);
	 for(int i=0;i<5;i++){
		 deptDao.findAll(page).forEach(System.out::println);
		 page=page.next();
		 //page= (Pageable) new PageRequest(0, 10,new Sort(Sort.Direction.ASC, "name"));
	 }
		return "done";
	}
}
