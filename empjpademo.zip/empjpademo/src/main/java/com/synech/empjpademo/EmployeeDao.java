package com.synech.empjpademo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Transactional;

public interface EmployeeDao extends JpaRepository<Employee, Integer>{
	
	public List<Employee> findByName(String name);

	public List<Employee> findByDepartmentAndName(String department,String name);

	public List<Employee> findByDepartmentOrName(String department,String name);

	@Modifying
	@Transactional
	@Query(nativeQuery = true,value="update Employee u set u.name = ?1 where u.empno = ?2")
	int setName(String name, Integer empNo);
}
