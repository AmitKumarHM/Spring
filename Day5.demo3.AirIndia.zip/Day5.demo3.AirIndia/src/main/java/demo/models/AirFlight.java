package demo.models;


public class AirFlight {
	private String frm;
	private String to ;
	private double cost;
	public AirFlight(){}
	public AirFlight(String frm, String to, double cost) {
		this.frm = frm;
		this.to = to;
		this.cost = cost;
	}
	
	public String getFrm() {
		return frm;
	}

	public void setFrm(String frm) {
		this.frm = frm;
	}

	public String getTo() {
		return to;
	}

	public void setTo(String to) {
		this.to = to;
	}

	public double getCost() {
		return cost;
	}

	public void setCost(double cost) {
		this.cost = cost;
	}

	@Override
	public String toString() {
		return "AirFlight [frm=" + frm + ", to=" + to + ", cost=" + cost + "]";
	}
	
	
}
