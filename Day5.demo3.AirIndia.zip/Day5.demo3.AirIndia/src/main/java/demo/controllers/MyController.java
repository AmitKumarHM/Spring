package demo.controllers;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collector;
import java.util.stream.Collectors;

import javax.xml.ws.Response;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;


import demo.models.AirFlight;

@RestController
@RequestMapping(value="/")
public class MyController {
	
	@GetMapping(produces={MediaType.APPLICATION_JSON_VALUE,MediaType.APPLICATION_XML_VALUE})
	public List<AirFlight> list(){
		List<AirFlight> list = new ArrayList<AirFlight>();
		list.add(new AirFlight("PNQ","DEL",1111.10));
		list.add(new AirFlight("DEL","PNQ",222.22));
		list.add(new AirFlight("HYD","DEL", 3333.33));
		list.add(new AirFlight("DEL","HYD", 43334));
		list.add(new AirFlight("HYD","PNQ", 5554));
		list.add(new AirFlight("PNQ","HYD", 6555));
		return list;
	}
	
}
